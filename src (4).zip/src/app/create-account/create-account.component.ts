import { Component, OnInit } from '@angular/core';
import { CustomerServiceService, WalletAccount, WalletUser, WalletTransactions } from '../customer-service.service';
import { Router } from '@angular/router';
//import {WalletAccount, WalletUser } from '../walletuser';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  //WalletTransactions:WalletTransactions[]=new WalletTransactions( [(0)] ,[(""], [""], [0], [0]  );
  //walletaccount:WalletAccount= { accountId: 0, accountBalance: 0, status: "",
  //'WalletUser': { userId: 0, userName: "", password: "", phoneNumber: 0, loginName:""},
  //'WalletTransactions' :[{ transactionId: 0, description:"", dateOfTransaction:"", amount:0 , accountBalance: 0 }]  
//};

//user:WalletAccount = new WalletAccount(0, 0, "",this.walletaccount.WalletUser,this.walletaccount.WalletTransactions);
//wallettransactions:WalletTransactions[];
//wallettransactions:WalletTransactions = new WalletTransactions(0, "", "", 0,0);
// walletuser :WalletUser= new WalletUser(0, "", "", 0, "");
// wallettransactions: WalletTransactions[];
//user:WalletAccount = new WalletAccount(0, 0, "",this.walletuser,this.wallettransactions);
//this.wallettransactions[{transactionId:0, description: "",dateOfTransaction:"",amount:0 ,accountBalance:0 } ]
user:WalletUser;
response:any
userSend:WalletAccount=new WalletAccount(0,0,'',{ user_Id: 0, user_Name: "", password: "", phone_Number: 0, login_Name:""},[{ transactionId: 0, description:"", dateOfTransaction:"", amount:0 , accountBalance: 0 }])
  constructor(private customerservice: CustomerServiceService, private router: Router) { }
  ngOnInit(): void {
  }
  //createAccount(user:WalletUser):void{
    onSubmit(user:WalletUser){
    // this.userSend.accountId=0;
    // this.userSend.accountBalance=0;
    // this.userSend.status="";
    // this.userSend.WalletUser={userId:Math.random(),userName:user.userName,password:user.password,phoneNumber:user.phoneNumber,loginName:user.loginName}
    // this.userSend.WalletTransactions=[{
    //   transactionId:0, description: "",dateOfTransaction:"",amount:0 ,accountBalance:0
    // }]
    console.log("user"+user)
    console.log(user.user_Name)
    this.userSend.walletUser=user
    // console.log(this.userSend.walletUser.userName)
    // this.userSend.walletUser.password=user.password; 
    // this.userSend.walletUser.phoneNumber=user.phoneNumber;
    // this.userSend.walletUser.loginName=user.loginName;
    console.log(this.userSend)

    this.customerservice.createAccount(this.userSend)
        .subscribe(data => {
          console.log(data)
          if(data!=null)
          {
           //this.response=data;
            alert("Account created successfully"); 
          }  
          else{
           alert("error");
           this.router.navigate(['create-account']);
              }
         } );
    }}
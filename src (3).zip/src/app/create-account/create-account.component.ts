import { Component, OnInit } from '@angular/core';
import { CustomerServiceService, WalletAccount, WalletUser, WalletTransactions } from '../customer-service.service';
import { Router } from '@angular/router';
//import {WalletAccount, WalletUser } from '../walletuser';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  //WalletTransactions:WalletTransactions[]=new WalletTransactions( [(0)] ,[(""], [""], [0], [0]  );
  //walletaccount:WalletAccount= { accountId: 0, accountBalance: 0, status: "",
  //'WalletUser': { userId: 0, userName: "", password: "", phoneNumber: 0, loginName:""},
  //'WalletTransactions' :[{ transactionId: 0, description:"", dateOfTransaction:"", amount:0 , accountBalance: 0 }]  
//};

//user:WalletAccount = new WalletAccount(0, 0, "",this.walletaccount.WalletUser,this.walletaccount.WalletTransactions);
//wallettransactions:WalletTransactions[];
//wallettransactions:WalletTransactions = new WalletTransactions(0, "", "", 0,0);
// walletuser :WalletUser= new WalletUser(0, "", "", 0, "");
// wallettransactions: WalletTransactions[];
//user:WalletAccount = new WalletAccount(0, 0, "",this.walletuser,this.wallettransactions);
//this.wallettransactions[{transactionId:0, description: "",dateOfTransaction:"",amount:0 ,accountBalance:0 } ]
user:WalletUser;
response:any
  constructor(private customerservice: CustomerServiceService, private router: Router) { }
  ngOnInit(): void {
  }
  createAccount(user:WalletUser):void{
    let userSend:WalletAccount;
    userSend.accountId=0;
    userSend.accountBalance=0;
    userSend.status="";
    userSend.WalletUser={userId:0,userName:user.userName,password:user.password,phoneNumber:user.phoneNumber,loginName:user.loginName}
    userSend.WalletTransactions=[{
      transactionId:0, description: "",dateOfTransaction:"",amount:0 ,accountBalance:0
    }]
    console.log("ts"+user);
    this.customerservice.createAccount(userSend)
        .subscribe(data => {
          if(data!=null)
          {
           //this.response=data;
            alert("Account created successfully"); 
          }  
          else{
           alert("error");
           this.router.navigate(['create-account']);
              }
         } );
    }}
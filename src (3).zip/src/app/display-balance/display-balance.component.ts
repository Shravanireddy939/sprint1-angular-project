import { Component, OnInit } from '@angular/core';
import { CustomerServiceService, WalletAccount, WalletUser, WalletTransactions } from '../customer-service.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-display-balance',
  templateUrl: './display-balance.component.html',
  styleUrls: ['./display-balance.component.css']
})
export class DisplayBalanceComponent implements OnInit {
  
  WalletTransactions:WalletTransactions[];
  walletaccount:WalletAccount= { accountId: 0, accountBalance: 0, status: "",
  'WalletUser': { userId: 0, userName: "", password: "", phoneNumber: 0, loginName:""},
  'WalletTransactions' :[{ transactionId: 0, description:"", dateOfTransaction:"", amount:0 , accountBalance: 0 }]  
};

userId:WalletUser;
       accountNo: number;
    
       amount:number;
   
       result:any;
       message: string;
       error: boolean;
       data: any;
  constructor(private customerservice: CustomerServiceService, private routing:ActivatedRoute, private router: Router) { }

  ngOnInit(): void 
  { //retriving userdata from login page 
    let user=this.routing.snapshot.paramMap.get('userId');
let userId=Number(user); /** snapshot returns string */
    console.log(userId);
     this.customerservice.displayBalance(userId)
     .subscribe((response) =>{

       if(response!=null)
       { 
         this.result = response;
                  }
                  else{
                   this.message='please enter the details';
                  }           
               });

 this.router.navigate(['display-balance',userId]);
}

       }


  